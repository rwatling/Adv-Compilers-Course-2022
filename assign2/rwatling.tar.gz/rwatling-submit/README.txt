Compilation workflow is in the run_proj2.sh bash script

Additionally, the functions appear to be iterated over twice so many of the basic blocks are repeated.

For the output of my execution of the bash script, go to the gvn, lvn, or svn directories.
